package com.minimarket.service.impl;

import com.minimarket.entity.DetalleVenta;
import com.minimarket.entity.Producto;
import com.minimarket.entity.Usuario;
import com.minimarket.entity.Venta;
import com.minimarket.repository.VentaRepository;
import com.minimarket.service.UsuarioService;
import com.minimarket.service.VentaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VentaServiceImpl implements VentaService {

    @Autowired
    private VentaRepository ventaRepository;

    @Autowired
    private UsuarioService usuarioService;

    @Override
    public List<Venta> findAll() {
        return ventaRepository.findAll();
    }

    @Override
    public Venta findById(Long id) {
        return ventaRepository.findById(id).orElse(null);
    }

    @Override
    public Venta save(Venta venta) {
        return ventaRepository.save(venta);
    }

    @Override
    public List<Venta> findByUsuarioId(Long usuarioId) {
        return ventaRepository.findByUsuarioId(usuarioId);
    }

    @Override
    public boolean tieneStockSuficiente(Venta venta) {
        if (venta == null || venta.getDetalles() == null || venta.getDetalles().isEmpty()) {
            return false;
        }
        for (DetalleVenta detalle : venta.getDetalles()) {
            Producto producto = detalle.getProducto();
            Integer cantidad = detalle.getCantidad();
            if (producto == null || producto.getStock() == null || cantidad == null || cantidad <= 0) {
                return false;
            }
            if (producto.getStock() < cantidad) {
                return false;
            }
        }
        return true;
    }

    @Override
    public double calcularTotal(Venta venta) {
        if (venta == null || venta.getDetalles() == null) {
            return 0.0;
        }
        return venta.getDetalles().stream()
                .mapToDouble(detalle -> {
                    double precio = detalle.getPrecio() != null ? detalle.getPrecio() : 0.0;
                    int cantidad = detalle.getCantidad() != null ? detalle.getCantidad() : 0;
                    return precio * cantidad;
                })
                .sum();
    }

    @Override
    public boolean tieneUsuarioValido(Venta venta) {
        if (venta == null || venta.getUsuario() == null || venta.getUsuario().getId() == null) {
            return false;
        }
        Usuario usuario = venta.getUsuario();
        return usuarioService.findById(usuario.getId())
                .map(usuarioEncontrado -> usuarioService.tieneDatosObligatoriosCompletos(usuarioEncontrado)
                        && usuarioService.tieneRolValidoParaRegistrarVenta(usuarioEncontrado))
                .orElse(false);
    }

    @Override
    public Venta registrarVenta(Venta venta) {
        if (!tieneUsuarioValido(venta)) {
            throw new IllegalArgumentException("La venta debe estar asociada a un usuario valido");
        }
        if (!tieneStockSuficiente(venta)) {
            throw new IllegalArgumentException("No existe stock suficiente para registrar la venta");
        }
        return ventaRepository.save(venta);
    }
}
