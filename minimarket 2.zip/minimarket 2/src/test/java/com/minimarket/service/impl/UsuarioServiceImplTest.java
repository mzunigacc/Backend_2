package com.minimarket.service.impl;

import com.minimarket.entity.Rol;
import com.minimarket.entity.Usuario;
import com.minimarket.repository.UsuarioRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UsuarioServiceImplTest {

    @Mock
    private UsuarioRepository usuarioRepository;

    @InjectMocks
    private UsuarioServiceImpl usuarioService;

    @Test
    @DisplayName("Debe validar usuario con datos obligatorios completos")
    void tieneDatosObligatoriosCompletos_UsuarioCompleto_RetornaTrue() {
        // Arrange
        Usuario usuario = crearUsuarioCompleto("cliente1", "CLIENTE");

        // Act
        boolean resultado = usuarioService.tieneDatosObligatoriosCompletos(usuario);

        // Assert
        assertTrue(resultado);
    }

    @Test
    @DisplayName("Debe rechazar usuario sin email")
    void tieneDatosObligatoriosCompletos_SinEmail_RetornaFalse() {
        // Arrange
        Usuario usuario = crearUsuarioCompleto("cliente1", "CLIENTE");
        usuario.setEmail(" ");

        // Act
        boolean resultado = usuarioService.tieneDatosObligatoriosCompletos(usuario);

        // Assert
        assertFalse(resultado);
    }

    @Test
    @DisplayName("Debe validar rol permitido para registrar ventas")
    void tieneRolValidoParaRegistrarVenta_RolValido_RetornaTrue() {
        // Arrange
        Usuario usuario = crearUsuarioCompleto("empleado1", "EMPLEADO");

        // Act
        boolean resultado = usuarioService.tieneRolValidoParaRegistrarVenta(usuario);

        // Assert
        assertTrue(resultado);
    }

    @Test
    @DisplayName("Debe rechazar usuario sin roles para registrar ventas")
    void tieneRolValidoParaRegistrarVenta_SinRoles_RetornaFalse() {
        // Arrange
        Usuario usuario = crearUsuarioCompleto("cliente1", "CLIENTE");
        usuario.setRoles(Set.of());

        // Act
        boolean resultado = usuarioService.tieneRolValidoParaRegistrarVenta(usuario);

        // Assert
        assertFalse(resultado);
    }

    @Test
    @DisplayName("Debe simular busqueda de usuario por username usando Mockito")
    void findByUsername_UsuarioExiste_RetornaUsuarioMockeado() {
        // Arrange
        Usuario usuario = crearUsuarioCompleto("admin", "ADMIN");
        when(usuarioRepository.findByUsername("admin")).thenReturn(Optional.of(usuario));

        // Act
        Optional<Usuario> resultado = usuarioService.findByUsername("admin");

        // Assert
        assertTrue(resultado.isPresent());
        assertEquals("admin", resultado.get().getUsername());
        verify(usuarioRepository, times(1)).findByUsername("admin");
    }

    private Usuario crearUsuarioCompleto(String username, String rol) {
        Usuario usuario = new Usuario();
        usuario.setId(1L);
        usuario.setUsername(username);
        usuario.setPassword("password123");
        usuario.setNombre("Juan");
        usuario.setApellido("Perez");
        usuario.setEmail(username + "@minimarket.cl");
        usuario.setDireccion("Av. Siempre Viva 123");
        usuario.setRoles(Set.of(new Rol(rol)));
        return usuario;
    }
}
