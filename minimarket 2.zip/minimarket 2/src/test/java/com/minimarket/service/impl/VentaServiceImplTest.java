package com.minimarket.service.impl;

import com.minimarket.entity.DetalleVenta;
import com.minimarket.entity.Producto;
import com.minimarket.entity.Rol;
import com.minimarket.entity.Usuario;
import com.minimarket.entity.Venta;
import com.minimarket.repository.VentaRepository;
import com.minimarket.service.UsuarioService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class VentaServiceImplTest {

    @Mock
    private VentaRepository ventaRepository;

    @Mock
    private UsuarioService usuarioService;

    @InjectMocks
    private VentaServiceImpl ventaService;

    @Test
    @DisplayName("Debe confirmar stock suficiente cuando la cantidad solicitada es menor al stock")
    void tieneStockSuficiente_StockDisponible_RetornaTrue() {
        // Arrange
        Venta venta = crearVentaConProducto(10, 3, 1500.0);

        // Act
        boolean resultado = ventaService.tieneStockSuficiente(venta);

        // Assert
        assertTrue(resultado);
    }

    @Test
    @DisplayName("Debe rechazar venta cuando no existe stock suficiente")
    void tieneStockSuficiente_StockInsuficiente_RetornaFalse() {
        // Arrange
        Venta venta = crearVentaConProducto(2, 5, 1500.0);

        // Act
        boolean resultado = ventaService.tieneStockSuficiente(venta);

        // Assert
        assertFalse(resultado);
    }

    @Test
    @DisplayName("Debe calcular correctamente el total de una venta")
    void calcularTotal_DosProductos_RetornaSumaCorrecta() {
        // Arrange
        Venta venta = new Venta();
        DetalleVenta arroz = crearDetalle(20, 2, 1590.0);
        DetalleVenta leche = crearDetalle(15, 3, 1200.0);
        venta.setDetalles(List.of(arroz, leche));

        // Act
        double total = ventaService.calcularTotal(venta);

        // Assert
        assertEquals(6780.0, total);
    }

    @Test
    @DisplayName("Debe retornar total cero cuando la venta no tiene detalles")
    void calcularTotal_SinDetalles_RetornaCero() {
        // Arrange
        Venta venta = new Venta();
        venta.setDetalles(List.of());

        // Act
        double total = ventaService.calcularTotal(venta);

        // Assert
        assertEquals(0.0, total);
    }

    @Test
    @DisplayName("Debe validar relacion entre venta y usuario existente con datos completos")
    void tieneUsuarioValido_UsuarioExistenteCompleto_RetornaTrue() {
        // Arrange
        Usuario usuario = crearUsuarioCompleto();
        Venta venta = new Venta();
        venta.setUsuario(usuario);
        when(usuarioService.findById(1L)).thenReturn(Optional.of(usuario));
        when(usuarioService.tieneDatosObligatoriosCompletos(usuario)).thenReturn(true);
        when(usuarioService.tieneRolValidoParaRegistrarVenta(usuario)).thenReturn(true);

        // Act
        boolean resultado = ventaService.tieneUsuarioValido(venta);

        // Assert
        assertTrue(resultado);
        verify(usuarioService).findById(1L);
        verify(usuarioService).tieneDatosObligatoriosCompletos(usuario);
        verify(usuarioService).tieneRolValidoParaRegistrarVenta(usuario);
    }

    @Test
    @DisplayName("Debe lanzar excepcion al registrar venta sin stock suficiente")
    void registrarVenta_SinStock_LanzaExcepcion() {
        // Arrange
        Usuario usuario = crearUsuarioCompleto();
        Venta venta = crearVentaConProducto(1, 4, 2500.0);
        venta.setUsuario(usuario);
        when(usuarioService.findById(1L)).thenReturn(Optional.of(usuario));
        when(usuarioService.tieneDatosObligatoriosCompletos(usuario)).thenReturn(true);
        when(usuarioService.tieneRolValidoParaRegistrarVenta(usuario)).thenReturn(true);

        // Act + Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> ventaService.registrarVenta(venta));
        assertEquals("No existe stock suficiente para registrar la venta", exception.getMessage());
        verify(ventaRepository, never()).save(any(Venta.class));
    }

    @Test
    @DisplayName("Debe registrar venta cuando usuario y stock son validos")
    void registrarVenta_UsuarioYStockValidos_GuardaVenta() {
        // Arrange
        Usuario usuario = crearUsuarioCompleto();
        Venta venta = crearVentaConProducto(10, 2, 3000.0);
        venta.setId(7L);
        venta.setUsuario(usuario);
        venta.setFecha(new Date());
        when(usuarioService.findById(1L)).thenReturn(Optional.of(usuario));
        when(usuarioService.tieneDatosObligatoriosCompletos(usuario)).thenReturn(true);
        when(usuarioService.tieneRolValidoParaRegistrarVenta(usuario)).thenReturn(true);
        when(ventaRepository.save(venta)).thenReturn(venta);

        // Act
        Venta resultado = ventaService.registrarVenta(venta);

        // Assert
        assertNotNull(resultado);
        assertEquals(7L, resultado.getId());
        verify(ventaRepository, times(1)).save(venta);
    }

    private Venta crearVentaConProducto(int stock, int cantidad, double precio) {
        Venta venta = new Venta();
        venta.setDetalles(List.of(crearDetalle(stock, cantidad, precio)));
        return venta;
    }

    private DetalleVenta crearDetalle(int stock, int cantidad, double precio) {
        Producto producto = new Producto();
        producto.setId(1L);
        producto.setNombre("Arroz 1kg");
        producto.setStock(stock);
        producto.setPrecio(precio);

        DetalleVenta detalle = new DetalleVenta();
        detalle.setProducto(producto);
        detalle.setCantidad(cantidad);
        detalle.setPrecio(precio);
        return detalle;
    }

    private Usuario crearUsuarioCompleto() {
        Usuario usuario = new Usuario();
        usuario.setId(1L);
        usuario.setUsername("cliente1");
        usuario.setPassword("password123");
        usuario.setNombre("Ana");
        usuario.setApellido("Gonzalez");
        usuario.setEmail("ana.gonzalez@minimarket.cl");
        usuario.setDireccion("Calle Central 456");
        usuario.setRoles(Set.of(new Rol("CLIENTE")));
        return usuario;
    }
}
