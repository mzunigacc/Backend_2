package com.minimarket.config;

import com.minimarket.entity.Rol;
import com.minimarket.entity.Usuario;
import com.minimarket.repository.RolRepository;
import com.minimarket.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Set;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initData(RolRepository rolRepository,
                               UsuarioRepository usuarioRepository,
                               PasswordEncoder passwordEncoder) {
        return args -> {
            Rol admin = crearRolSiNoExiste(rolRepository, "ROLE_ADMIN");
            Rol empleado = crearRolSiNoExiste(rolRepository, "ROLE_EMPLEADO");
            Rol cliente = crearRolSiNoExiste(rolRepository, "ROLE_CLIENTE");

            crearUsuarioSiNoExiste(usuarioRepository, passwordEncoder, "admin", "admin123", Set.of(admin));
            crearUsuarioSiNoExiste(usuarioRepository, passwordEncoder, "empleado", "empleado123", Set.of(empleado));
            crearUsuarioSiNoExiste(usuarioRepository, passwordEncoder, "cliente", "cliente123", Set.of(cliente));
        };
    }

    private Rol crearRolSiNoExiste(RolRepository rolRepository, String nombre) {
        return rolRepository.findByNombre(nombre).orElseGet(() -> {
            Rol rol = new Rol();
            rol.setNombre(nombre);
            return rolRepository.save(rol);
        });
    }

    private void crearUsuarioSiNoExiste(UsuarioRepository usuarioRepository,
                                        PasswordEncoder passwordEncoder,
                                        String username,
                                        String password,
                                        Set<Rol> roles) {
        if (usuarioRepository.findByUsername(username).isEmpty()) {
            Usuario usuario = new Usuario();
            usuario.setUsername(username);
            usuario.setPassword(passwordEncoder.encode(password));
            usuario.setRoles(roles);
            usuarioRepository.save(usuario);
        }
    }
}
